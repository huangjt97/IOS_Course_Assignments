//Exercise 1
func Exercise_1(x: Int, y: Int) -> Int {
    //return sum of 2 integers
    return (x+y)
}

//Sample output
print("The sum is",Exercise_1(x: 5, y: 6))



//Exercise 2
let n1: Int    = 1
let n2: Float  = 2.0
let n3: Double = 3.34

//Sum of different data types
//Original: var result = n1 + n2 + n3
var result = Double(n1) + Double(n2) + n3 //Fixed
//The Error is caused because variables cannot operate without converting into the same datatype

//Sample output
print("The sum is",result)

//Exercise 3
class Exercise_3 {
    //Declare type
    var n: Int
    
    //Initialization
    init() {
        n = 0
    }
    
    init(x: Int) {
        n = x
    }
    //init initializes the values in class or struct, so it would have a default value when created
    
    //Function to change n value
    func change() {
        n = n + 1
    }
}

//Test output for Initialization
var test  = Exercise_3()
print(test.n)
var test2 = Exercise_3(x: 5)
print(test2.n)

//Test output after changing n
test.change()
print(test.n)

//Exercise 4
//Create protocol
protocol people{
    var name: String {get}
    var age : Int    {get}
}
//Protocols set up a default method in swift that can be adopted to class or structures.

//Examples for structure that used the protocol
struct movieStar: people{
    let name: String = "Jackie Chan"
    let age : Int    = 68
}

//Test output
let star = movieStar()
print(star.name,star.age)



//Exercise 5
//?? takes the first none nil value
//Example
let x: Int? = nil
let y: Int? = 0
let z: Int  = 1
var answer  = x ?? z //Takes z, because x is nil

//Test nil output
print(answer)
//Test optional variable with value output
    answer  = y ?? z //Takes y, because y comes first
print(answer)



//Exercise 6
//Guard transfer program control out of scope when conditions are not met
//It is like "if" but opposite
//Requires "return" or "continue" to end the method
//Example
for i in 1...10 {
    //Guard statement
    guard(i % 2 == 0) else {
    //Although the condition is for even numbers,
    //it actually runs when i is an odd number
        
        print("\(i) ", terminator: "")
        continue
        //Ends the current method
    }
}

//Sample output
print("are odd numbers")



//Exercise 7
//The Three Primary Collection Types in Swift are Arrays, Sets, and Dictionaries. Arrayed are ordered collections of values. Sets are unordered collection of unique values stored using hash. Dictionaries are unordered collections of key-value associations.
//Example
let a: Array      = ["A","B","C","D","D"]
var s: Set        = ["A","B","C","D"]
var d: Dictionary = ["1": "A","2": "B","3": "C","4": "D"]

//Add duplicates to Set and Dictionary for testing
s.insert("D")
//Set has unique values

d["4"] = "E"
d["5"] = "A"
//Dictionary has unique keys, but values can have duplicates

//Sample output
print(a)
print(s)
print(d)



//Exercise 8
//The main differences between structures and classes in Swift is that "class" is refference type while "struct" is value type
//Create sample structure
struct struct1{
    var name: String = "Tom"
}

/*
struct cannot inherit from other struct
struct struct2: struct1 {
    var age: Int = 10
}
*/

//Create sample class
class class1{
    var name: String = "Jerry"
    
    //Class can deinitialize
    deinit {
        print("Removed \(name) from list")
    }
}

//Class can inherit from other class
class class0: class1{
    var age: Int = 10
    
    //Class can deinitialize
    deinit {
        print("Removed \(name) \(age) from list")
    }
}


//Create test samples
var testStruct1 = struct1()
var testStruct2 = testStruct1
var testClass1  = class1()
var testClass2  = testClass1

//Change the latter for each for testing
testStruct2.name = "Ted"
testClass2.name  = "Josh"

//Sample output
print(testStruct1.name,testStruct2.name)
print(testClass1.name ,testClass2.name)



//Exercise 9
//Optional Chaining is the process of querying and calling properties, methods, subscripts on an optional that might currently be nil.
//Example
class Job {
    var salary: Int
    init() {
        salary = 25
    }
}

//Creating a class with optional variable chained with another class
class person {
    var work: Job?
    /*
    init() {
        work = Job()
    }
    */
}

//Test
var Ana = person()
if let money = Ana.work?.salary {
    print("Ana's job pays her \(money) per hour")
} else {
    print("Ana is unemployed")
}



//Exercise 10
//Optional binding is a mechanism built into Swift to safely unwrap optionals.
//var emotional: String? = "Happy"
var emotional: String? = nil

//Test output
if let emo = emotional {
    print("Ana is currently \(emo)")
} else {
    print("Ana is not feeling anything right now")
}

//Exercise 11
//An In-Out Parameter is used to make a constant in the parameter into a variable that pass its value out the function
//Example
func ioTest(time: inout Int) {
    time = time + 100
    return
}

//Example
var t = 0
ioTest(time: &t)

//Sample output
print("\(t) units of time have passed")



//Exercise 12
//It is possible to give a default value to a function parameter
//Example
func paint(color: String = "Red") {
    print(color)
    return
}

//Test output
paint()
paint(color: "Blue")



//Exercise 13
//Force unwrapping is by using "!" to unwrap an optional variable. It should only be used when the optional variable has a value, not nil. Or else, the program will throw an Error.
//Example
let flower : String? = nil
let flower2: String? = "Lily"

//Sample output
//print(flower!)     //Throws an Error for force unwrapping
if let flowerTemp = flower{
    print(flowerTemp)
} else {
    print("This is not a flower")
}
print(flower2!)
//So only use force unwrapping when the Optional variable is checked not nil before unwrapping



//Exercise 14
//struct in Swift holds constants in default, Mutating keyword allows them to be changed.
//Example
struct food{
    var name: String
    mutating func change(daily: String){
        name = daily
    }
}

//Sample output
var setA = food(name: "Fish")
setA.change(daily: "Sushi")
print("Set A has \(setA.name) in it")



//Exercise 15
//Deinitializer is for changing variables before the system automaticly deallocate the resources that are not used.
//Example
class student {
    var name: String = "Noname"
    init(name1: String) {
        name = name1
    }
    
    deinit {
        print("\(name) no longer is a student in Class")
    }
}

//Sample
var classA : [student] = []
classA.append(student(name1: "Carl"))
print("\(classA[0].name) is in Class A")

//Remove all to activate deinit
classA.removeAll()



//Exercise 16
//Protocols set up a default method in swift that can be adopted to class or structures.
//Example is in Exercise 4



//Exercise 17
//The difference between a protocol and a class is that a protocol is abstract and made for grouping method, functions and properties; on the other hand, classes are used for creating the actual context of the method, function, and properties.
//Example
protocol gameCharacter{
    var name: String{get}
    func voiceLine()
}

class npc: gameCharacter{
//The class must include the variable, functions and etc. as protocol. It can have more if needed
    
    var name = "Dio"
    var age  = 10
    
    func voiceLine() {
        print("\(name): NoNoNoNoNo")
    }
}

//Sample output
let dio = npc()
dio.voiceLine()



//Exercise 18
//Fix the Code
struct Apple{

}

func pick(apple: Apple?) {
    guard let apple = apple else {
        print("No apple found!")
        return //fixed
        //The code was missing an exit out of guard
    }
    print(apple)
}

//Sample output
let app = Apple()
pick(apple: nil)
pick(apple: app)



//Exercise
//Inherit multiple protocols in same class
protocol pic{
    var color: String{get}
    func draw(c: String)
}

protocol model{
    var name: String{get}
    func voiceLine()
}

class player: pic, model {
    //Meets requirements for both protocols
    var color: String = "Red"
    var name : String = "Eric"
    func draw(c: String) {
        color = c
        return
    }
    func voiceLine() {
        print("Greetings")
        return
    }
}

//Sample output
let eric = player()
eric.draw(c: "Blue")
print(eric.name,eric.color)
eric.voiceLine()



//Exercise 20
//Append one array to another
var first  = ["John"  , "Paul"]
let second = ["George", "Ringo"]
//first.append(contentsOf: second)
first += second

//Sample output
print(first)
