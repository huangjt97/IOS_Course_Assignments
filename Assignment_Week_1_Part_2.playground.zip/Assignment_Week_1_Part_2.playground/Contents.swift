func Exercise_15() {
    //Assign tuple
    let player = (8, "Igor Larionov")
    //Test output
    print(player)
    
    return
}

func Exercise_16() {
    //Decompose player tuple into separate constants
    let player = (number: 8, name: "Igor Larionov")
    let player2 :(number: Int, name: String) = (8, "Igor Larionov")
    let player3 : (number: Int, name: String)
    player3.number = 8
    player3.name = "Igor Larionov"
    
    //Test output
    print(player)
    print(player2)
    print(player3)
    
    return
}

func Exercise_17() {
    //Constant with optional type
    let cons : Int? = nil
    let cons2: Int? = 1
    
    //Test output
    if let unwrap = cons {
        print(unwrap)
    } else {
        print("nil")
    }
    if let unwrap2 = cons2 {
        print(unwrap2)
    } else {
        print("nil")
    }
    //Not Errors.
    
    return
}

func Exercise_18() {
    //Fix original optional constant by unwrapping
    let value: Int? = 17
    let banana: Int = value!
    /*
    Functional change, but not recommended
    "let banana: Int = value" did not work
    because value was an optional constant,
    while banana was not.
    Unwrap value then assign to banana
    */
    
    //Test output
    print(banana)
    
    return
}

func Exercise_19() {
    //If the optional value was nil
    let value: Int? = nil
    if let unwrap = value {
        //unwrap value is not nil
        let banana: Int = unwrap
        
        //Test output
        print(banana)
    } else {
        
        //let banana: Int = value!
        //Throw error for unwrapping an Optional value with nil
        
        //Output unwrap failure because value is nil
        print("Unwrap failure")
    }
    
    return
}

func Exercise_20() {
    //If the optional value was nil
    let value: Int? = nil
    
    //Check before unwrap
    if let unwrap = value {
        //unwrap value is not nil
        let banana: Int = unwrap
        
        //Test output
        print(banana)
    } else {
        //Output unwrap failure because value is nil
        print("Unwrap failure")
    }
    
    return
}

func Exercise_21() {
    //Function for the operation
    func Add(x: Int = 0,y: Int = 0) -> Int {
        if (x != y) {
            //Returns sum for unequal numbers
            return (x+y)
        } else {
            //Returns triple of sum for equal numbers
            return (3*(x+y))
        }
    }
    
    //Test output
    print("The answer is",Add(x: 4,y: 5))
    print("The answer is",Add(x: 5,y: 5))
    
    return
}

func Exercise_22() {
    
    func check5(numbers:[Int]) -> Bool {
        //Check first
        if (numbers.first == 5) {
            return(true)
            //The first element in array is 5
        }
        
        //Check last
        if (numbers.last == 5) {
            return(true)
            //The last element in array is 5
        }
        
        //Neither the first nor the last in array is 5
        return(false)
    }
    
    //Initialize array
    let num = [1,2,3,4,5,6,7] //1...7
    //Check if 5 was found as first or last
    if check5(numbers: num) {
        //Output for 5 found first or last
        print("5 was found as first or last")
    } else {
        //Output for 5 not found first or last
        print("5 was not found as first or last")
    }
    
    return
}

func Exercise_23() {
    //Function for reversing array
    func rev(arr: [Int]) -> [Int] {
        //There is a built-in function in the array library
        return (arr.reversed())
    }
    
    //Initialize the array
    let a = [1,2,3,4,5] //1...5
    //Test output
    print("The reversed array is", rev(arr: a))
    
    return
}

func Exercise_24() {
    //Create function to rotate an array to left by 1
    func rotateArray(arr: [Int]) -> [Int] {
        //Rotating is the same as deleting the first and adding it to the last
        //Record the first before deleting
        let firstNum = arr.first
        
        //Create temperary array for answer
        var temp = arr
        
        //Remove the first
        temp.removeFirst(1)
        
        //Add it to the last
        temp.append(firstNum!)
        
        //Return the rotated array
        return (temp)
    }
    
    //Initialize
    let a = [1,2,3,4,5]
    //Test output
    print("The rotated array is", rotateArray(arr: a))
    
    return
}

func Exercise_25() {
    //Create function to compute sum of elements in array
    func sum(arr: [Int]) -> Int {
        //Create variable to hold the sum
        var total : Int = 0
        //Loop for each element within the array
        for num in arr {
            //Add current element to sum
            total += num
        }
        
        //return sum
        return (total)
    }
    
    //Initialize
    let a = [1,2,3,4]
    //Test output
    print("The sum is", sum(arr: a))
    
    return
}

func Exercise_26() {
    //Create function to find difference
    func absDiff(n: Int) -> Int {
        //Check if num is larger than 51
        if (n>51) {
            //If so, return double absolute difference
            return (2*(n-51))
        } else {
            //If not, return absolute difference
            return (51-n)
        }
        //No need to use abs() because there is condition before subtraction
    }
    
    //Test output
    print("The absolute difference is", absDiff(n: 40))
    print("The absolute difference is", absDiff(n: 60))
    
    return
}

func Exercise_27() {
    //Create function to find 20
    func find20(x: Int,y: Int) -> Bool {
        //Check if first number is 20, second number is 20, or their sum is 20
        if (x == 20) || (y == 20) || (x+y == 20) {
            //Return true if appiable
            return true
        }
        
        //If none apply return false
        return false
    }
    
    //Test
    if find20(x: 1, y: 19) {
        //Found
        print("One of the two numbers or their sum is 20")
    } else {
        //Not found
        print("Neither of the two numbers nor their sum is 20")
    }
    
    return
}

func Exercise_28() {
    //Create function to check if two numbers have different signs
    func diffSign(x: Int,y: Int) -> Bool {
        //Check if x is positive and y is negative
        if ((x>0) && (y<0)) {
            return true
        }
        
        //Check if x is positive and y is negative
        if ((x<0) && (y>0)) {
            return true
        }
        
        //If both positive or both negative
        return false
    }
    
    //Test
    if diffSign(x: -1, y: 19) {
        //Opposite signs
        print("The two numbers have opposite signs")
    } else {
        //Same signs
        print("The two numbers have the same signs")
    }
    
    //Create function to check if two numbers are both negative
    func negative(x: Int,y: Int) -> Bool {
        //Check if both are negative
        if ((x<0) && (y<0)) {
            return true
        }
        
        //At least, one of them is positive
        return false
    }
    
    //Test
    if negative(x: -1, y: -19) {
        //Opposite signs
        print("The two numbers both are negative")
    } else {
        //Same signs
        print("At least one number is positive")
    }
    
    return
}

func Exercise_29() {
    //Create function to check if either of the two integers are in range of 10 to 30 inclusive
    func inRange(x: Int,y: Int) -> Bool {
        //Check if x is in range
        if ((10...30).contains(x)) {
            return true
        }
        
        //Check if y is in range
        if ((10...30).contains(y)) {
            return true
        }
        
        //If both are not in range
        return false
    }
    
    //Test
    if inRange(x: 1, y: 30) {
        //Either is in range
        print("Either of the two integers is in range")
    } else {
        //Neither is in range
        print("Neither of the two integers are in range")
    }
    
    return
}

func Exercise_30() {
    //Create function to change the first and last character of string
    func changeString(s: String) -> String {
        //Use temp for contain temperary string
        //Change the String into an array of characters
        var temp : [Character] = Array(s)
        
        //Change first character
        temp[0] = "D"
        
        //Change last character
        temp[temp.count-1] = "m"
        
        //return after changing array back to string
        return String(temp)
    }
    
    //Test
    print("The changed String is", changeString(s: "Nice Hat"))
    
    return
}


Exercise_15()
Exercise_16()
Exercise_17()
Exercise_18()
Exercise_19()
Exercise_20()
Exercise_21()
Exercise_22()
Exercise_23()
Exercise_24()
Exercise_25()
Exercise_26()
Exercise_27()
Exercise_28()
Exercise_29()
Exercise_30()
