//Exercise 1
func Exercise_1() {
  //Declare Double variable for temperature
  var Temperature : Double = 73.4
  
  //Print temperature
  print("The current temperature is \(Temperature)°F")
  
  //Assign different value to temperature variable
  Temperature = 75.7
  
  //Print temperature
  print("After a while, the temperature might be \(Temperature)°F")
  
  return
}

//Exercise 2
func Exercise_2() {
  //Declare Int constant for seconds in an hour
  let Seconds : Int = 3600
  
  //Print Seconds
  print("There are \(Seconds) in an hour")
  
  /*
  //Assign different value to constant
  Seconds = 3500
  //Throws an error, because Seconds is a constant
  //not a changable variable
  */

  return
}

//Exercise 3
func Exercise_3() {
  //Declare Int variable with an explicit type
  var exp : Int = 9
  
  //Print exp
  print("The Int variable with an explicit type is \(exp)")
  
  //Declare Int variable without an explicit type
  var non_exp = 1
  
  //Print non_exp
  print("The Int variable without an explicit type is \(non_exp)")

  return
}

//Exercise 4
func Exercise_4() {
  //Declare constant  for wheels of a car
  let wheel : Int
  wheel = 4
  
  //Print wheel
  print("A car has \(wheel) wheels")
  //This works because wheel is a constant
  //and constants can and only can be assigned a value once

  return
}

//Exercise 5
func Exercise_5() {
  //Declare constant π with name π
  let π : Double = Double.pi
  
  //Print π
  print("π has a value approximately \(π)")

  return
}

//Exercise 6
func Exercise_6() {
  //Declare variable with emoji in name
  var happy_😊 : Int = 1
  
  //Print variable
  print("happy_😊 has a value of \(happy_😊)")

  return
}

//Exercise 7
func Exercise_7() {
  //Declare variable
  var output : String = "answer"
  
  //Print variable
  print("Print \(output)")

  return
}

//Exercise 8
func Exercise_8() {
  //Declare maximum value in Int16
  let max_Int16 : Int16 = 32767

  //Print max_Int16
  print("The maximum value in Int16 is \(max_Int16)")
  /*
  Because Int16 contains all 16 bit binary numbers from
  -2^15 (-32768) to 2^15-1 (32767) by using the first
  digit as sign for negative and positive.
  It would contain all 16 bit binary numbers
  from 0 to 2^16 if it was for UInt16
  */

  //Declare constant pi with the value of π
  let pi = 3 + 0.141592654
  /*
  The constant pi is a Double, because 0.141592654
  has values on the right of floating point.
  Since Double has took place in the (final) calculation,
  pi cannot be an Int, and is assigned to Double by default
  */

  return
}

//Exercise 9
func Exercise_9() {
  /*
  //Declare UInt constant with negative number
  let myNumber : UInt = -17
  //Throws an error because UInt only contains unsigned integers
  */

  return
}

//Exercise 10
func Exercise_10() {
  /*
  //Declare Int constant with number above 32767
  let bigNumber : Int16 = 32767 + 1
  //Throws an error because Int16 only contains
  //integers from -32768 to 32767
  */

  return
}

//Exercise 11
func Exercise_11() {
  /*
  //Assign an approximate π value to constant pi
  let pi = 3.141592654
  //Declare Int variable approximatePi with the value of pi
  let approximatePi: Int = pi
  //Throws error, because approximatePi is declared
  //as an integer by type Int.
  */

  //Assign an approximate π value to constant pi
  let pi = 3.141592654
  //Declare Int variable approximatePi with the round value of pi
  let approximatePi: Int = Int(pi)
  //let approximatePi: Int = Int(round(pi))
  //Print value of approximatePi
  print("The value of approximatePi is \(approximatePi)")

  return
}

//Exercise 12
func Exercise_12() {
  //This is the single-line comment
  /*
  #########
  This is the multiline comment.
  #########
  */

  return
}

//Exercise 13
func Exercise_13() {
  /*
  Outer comment
  #########
  /*
  Inner comment
  This is the nested multiline comment.
  Inner comment
  */
  #########
  Outer comment
  */

  return
}

//Exercise 14
func Exercise_14() {
  //2 value assigned in one line
  var i : Int = 1; var j : Int = 0
  
  /* //2 type of comments on the same line */

  let k : Int = 1 //variable statement and comment on the same line

  return
}

Exercise_1()
Exercise_2()
Exercise_3()
Exercise_4()
Exercise_5()
Exercise_6()
Exercise_7()
Exercise_8()
Exercise_9()
Exercise_10()
Exercise_11()
Exercise_12()
Exercise_13()
Exercise_14()

